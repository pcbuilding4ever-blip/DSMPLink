# DSMPLink — Minecraft ↔ Discord linking

Paper 1.21.11 plugin for DSMP PvP.

## What it does
- Automatically opens a native Minecraft Dialog when a player joins.
- The dialog contains a 6-digit Discord linking code field.
- The player does not need to type a Minecraft command.
- Clicking Link Account sends the code, Minecraft UUID, and Minecraft name to the Discord bot API.
- The API response determines whether the account is linked.

Paper's Dialog API was introduced for this style of server-side input and is available in the Paper 1.21.11 API.

## Configuration
After first start, edit `plugins/DSMPLink/config.yml`:

```yaml
api-url: "https://YOUR-BOT-API/verify"
api-secret: "A-LONG-RANDOM-SECRET"
reopen-delay-seconds: 2
require-link-on-join: true
```

The Discord bot API is the next piece. It should accept:

```json
{
  "code": "583214",
  "minecraftUuid": "player-uuid",
  "minecraftName": "PlayerName"
}
```

with the secret in the `X-DSMP-Link-Secret` header and return JSON such as:

```json
{"success":true}
```

or:

```json
{"success":false,"error":"CODE_INVALID"}
```

Supported errors currently handled by the plugin:
- `CODE_INVALID`
- `CODE_EXPIRED`
- `ALREADY_LINKED`

## Build
The included GitHub Actions workflow builds the JAR with Java 21 and Gradle 8.14.3.

The output JAR is created at:

`build/libs/DSMPLink-1.0.0.jar`

Do not put a Discord bot token in this Minecraft plugin. The plugin uses a separate shared API secret instead.
